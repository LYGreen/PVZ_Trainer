#pragma once
#ifndef __SUN_H_
#define __SUN_H_

void StartInfiniteSun();
void EndInfiniteSun();

#endif // !__SUN_H_
