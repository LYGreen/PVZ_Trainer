#include <iostream>
#include <Windows.h>
#include "sun.h"
using namespace std;

extern DWORD GetOffsetPointer(HANDLE hProcess, DWORD ptr, int offsetCount, ...);
extern HANDLE gGameProcess;

const DWORD SUN_BASE_ADDRESS = 0x729670;
const DWORD SUN_INIFINTE_VALUE = 9990;

static DWORD sSun_Address;
static BOOL sInfinite = FALSE;

static DWORD WINAPI Infinite(LPVOID data)
{
	while (sInfinite)
	{
		Sleep(1);
		WriteProcessMemory(gGameProcess, (LPVOID)sSun_Address, &SUN_INIFINTE_VALUE, sizeof(DWORD), NULL);
	}
	return 0;
}

void StartInfiniteSun()
{
	sSun_Address = GetOffsetPointer(gGameProcess, SUN_BASE_ADDRESS, 2, 0x868, 0x5578);
	sInfinite = true;
	CreateThread(NULL, 0, Infinite, NULL, NULL, 0);
}

void EndInfiniteSun()
{
	sInfinite = false;
}
