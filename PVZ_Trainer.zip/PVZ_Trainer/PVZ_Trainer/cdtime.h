#pragma once
#ifndef __CDTIME_H_
#define __CDTIME_H_

void StartNoneCDTime();
void EndNoneCDTime();

#endif // !__CDTIME_H_
