#include <iostream>
#include <Windows.h>
using namespace std;

extern DWORD GetOffsetPointer(HANDLE hProcess, DWORD ptr, int offsetCount, ...);
extern HANDLE gGameProcess;

const DWORD MONEY_BASE_ADDRESS = 0x7296FC;
const DWORD MONEY_VALUE = 99999;

static DWORD sMoney_Address;
static BOOL sInfinite = FALSE;

static DWORD WINAPI Infinite(LPVOID data)
{
	while (sInfinite)
	{
		Sleep(1);
		WriteProcessMemory(gGameProcess, (LPVOID)sMoney_Address, &MONEY_VALUE, sizeof(DWORD), NULL);
	}
	return 0;
}

void StartInfiniteMoney()
{
	sMoney_Address = GetOffsetPointer(gGameProcess, MONEY_BASE_ADDRESS, 2, 0x94C, 0x50);
	sInfinite = TRUE;
	CreateThread(NULL, 0, Infinite, NULL, NULL, 0);
}

void EndInfiniteMoney()
{
	sInfinite = FALSE;
}
