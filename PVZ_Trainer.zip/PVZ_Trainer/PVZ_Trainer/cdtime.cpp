#include <iostream>
#include <Windows.h>
#include "cdtime.h"
using namespace std;

extern DWORD GetOffsetPointer(HANDLE hProcess, DWORD ptr, int offsetCount, ...);
extern HANDLE gGameProcess;

const DWORD CARD_BASE_ADDRESS = 0x50C740;
const DWORD CARD_NONE_CD_VALUE = 9990;

static DWORD sCard_Address[10];
static BOOL sNoneCD = FALSE;

static DWORD WINAPI NoneCDTime(LPVOID data)
{
	while (sNoneCD)
	{
		Sleep(50);
		/* �ڴ˹��������ڻ�ַָ����ܻ�ָ�� NULL����Ϊ��ȷ��ָ���ܻ�ȡ������ٲ��о����� */
		for (int i = 0; i < 50; i++)
		{
			sCard_Address[0] = GetOffsetPointer(gGameProcess, CARD_BASE_ADDRESS, 4, 0x3C, 0x28, 0x15C, 0x4C);
			if (sCard_Address[0] != NULL)
			{
				break;
			}
		}
		for (int i = 1; i <= 9; i++)
		{
			sCard_Address[i] = sCard_Address[0] + 0x50 * i;
		}
		/* ������ˢ�µ�ַ������ */

		for (int i = 0; i < 10; i++)
		{
			WriteProcessMemory(gGameProcess, (LPVOID)sCard_Address[i], &CARD_NONE_CD_VALUE, sizeof(DWORD), NULL);
		}
	}
	return 0;
}

void StartNoneCDTime()
{
	sNoneCD = TRUE;
	CreateThread(NULL, 0, NoneCDTime, NULL, 0, 0);
}
void EndNoneCDTime()
{
	sNoneCD = FALSE;
}
