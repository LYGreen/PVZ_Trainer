#pragma once
#ifndef __QUICKLY_KILL_H_
#define __QUICKLY_KILL_H_

void StartQuicklyKill();
void EndQuicklyKill();

#endif // !__QUICKLY_KILL_H_
