#pragma once
#ifndef __RUN_IN_BACKGROUND_H_
#define __RUN_IN_BACKGROUND_H_

void StartRunInBackground();
void EndRunInBackground();

#endif // !__RUN_IN_BACKGROUND_H_
