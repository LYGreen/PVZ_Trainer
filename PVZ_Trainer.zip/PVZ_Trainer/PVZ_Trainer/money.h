#pragma once
#ifndef __MONEY_H_
#define __MONEY_H_

void StartInfiniteMoney();
void EndInfiniteMoney();

#endif // !__MONEY_H_
