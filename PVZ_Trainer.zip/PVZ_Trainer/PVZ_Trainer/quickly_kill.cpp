#include <iostream>
#include <Windows.h>
#include "quickly_kill.h" /* instant kill ��ɱ */
using namespace std;

extern DWORD GetOffsetPointer(HANDLE hProcess, DWORD ptr, int offsetCount, ...);
extern HANDLE gGameProcess;

const DWORD ZOMBIE_SCREENDOOR_HP_CODE_ADDRESS = 0x00541651;/* ��դ�Ž�ʬ */
const DWORD ZOMBIE_CONEHEAD_HP_CODE_ADDRESS = 0x005419FA;/* ·�Ͻ�ʬ����Ͱ��ʬ... */
const DWORD ZOMBIE_HP_CODE_ADDRESS = 0x00541CE4;/* ��ͨ��ʬ */

static DWORD sAlloc_Zombie_Screendoor_hp_Inject_Code;
static DWORD sAlloc_Zombie_Conehead_hp_Inject_Code;
static DWORD sAlloc_Zombie_hp_Inject_Code;

#pragma region ��դ�Ž�ʬ

static CHAR sZombie_Screendoor_hp_Origin_Code[6] = {
	0x29,0x86,0xDC,0x00,0x00,0x00 /* sub [esi+000000DC],eax */
};

static CHAR sZombie_Screendoor_hp_Modified_Code[6] = {
	0xE9,0x00,0x00,0x00,0x00, /* jmp xxxxxxxx */
	0x90 /* nop */
};

static CHAR sZombie_Screendoor_hp_Inject_Code[15] = {
	0xC7,0x86,0xDC,0x00,0x00,0x00,0x00,0x00,0x00,0x00, /* mov [esi+000000DC],00000000 */
	0xE9,0x00,0x00,0x00,0x00 /* jmp xxxxxxxx */
};

#pragma endregion


#pragma region ·�Ͻ�ʬ

/* ԭ����Ϸ�Ļ����� */
static CHAR sZombie_Conehead_hp_Origin_Code[6] = {
	0x89,0x8D,0xD0,0x00,0x00,0x00 /* mov [ebp+000000D0],ecx */
};

/* �޸���Ϸ�Ļ����� */
static CHAR sZombie_Conehead_hp_Modified_Code[6] = {
	0xE9,0x00,0x00,0x00,0x00, /* jmp xxxxxxxx */
	0x90 /* nop */
};

/* ע����Ϸ�Ļ����� */
static CHAR sZombie_Conehead_hp_Inject_Code[15] = {
	0xC7,0x85,0xD0,0x00,0x00,0x00,0x00,0x00,0x00,0x00, /* mov [ebp+000000D0],00000000 */
	0xE9,0x00,0x00,0x00,0x00 /* jmp xxxxxxxx */
};

#pragma endregion

#pragma region ��ͨ��ʬ

/* ԭ����Ϸ�Ļ����� */
static CHAR sZombie_hp_Origin_Code[6] = {
	0x89,0xAF,0xC8,0x00,0x00,0x00 /* mov [edi+000000C8],ebp */
};

/* �޸���Ϸ�Ļ����� */
static CHAR sZombie_hp_Modified_Code[6] = {
	0xE9,0x00,0x00,0x00,0x00, /* jmp xxxxxxxx */
	0x90 /* nop */
};

/* ע����Ϸ�Ļ����� */
static CHAR sZombie_hp_Inject_Code[15] = {
	0xC7,0x87,0xC8,0x00,0x00,0x00,0x00,0x00,0x00,0x00, /* mov [edi+000000C8],00000000 */
	0xE9,0x00,0x00,0x00,0x00 /* jmp xxxxxxxx */
};

#pragma endregion



void StartQuicklyKill()
{
	DWORD offset, offset2, oldProtect;

	/* �޸���ͨ��ʬ�Ļ����� */
	sAlloc_Zombie_hp_Inject_Code = (DWORD)VirtualAllocEx(gGameProcess, NULL, sizeof(CHAR) * 2048, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	offset = sAlloc_Zombie_hp_Inject_Code - ZOMBIE_HP_CODE_ADDRESS - sizeof(CHAR) * 5;/* �� 5 ���ֽ���ʵ�Ǽ�ȥ jmp ָ���С */
	memcpy(&sZombie_hp_Modified_Code[1], &offset, sizeof(CHAR) * 4);/* 32λ����ĵ�ַ��4���ֽڣ�64λ����ĵ�ַ��8���ֽ� */

	offset2 = (ZOMBIE_HP_CODE_ADDRESS + sizeof(CHAR) * 6) - (sAlloc_Zombie_hp_Inject_Code + sizeof(CHAR) * 15);
	memcpy(&sZombie_hp_Inject_Code[11], &offset2, sizeof(CHAR) * 4);
	WriteProcessMemory(gGameProcess, (LPVOID)sAlloc_Zombie_hp_Inject_Code, sZombie_hp_Inject_Code, sizeof(CHAR) * 15, NULL);

	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_HP_CODE_ADDRESS, sizeof(CHAR) * 6, PAGE_EXECUTE_READWRITE, &oldProtect);
	WriteProcessMemory(gGameProcess, (LPVOID)ZOMBIE_HP_CODE_ADDRESS, sZombie_hp_Modified_Code, sizeof(CHAR) * 6, NULL);
	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_HP_CODE_ADDRESS, sizeof(CHAR) * 6, oldProtect, &oldProtect);

	/* �޸�·�Ͻ�ʬ�Ļ����� */
	sAlloc_Zombie_Conehead_hp_Inject_Code = (DWORD)VirtualAllocEx(gGameProcess, NULL, sizeof(CHAR) * 2048, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	offset = sAlloc_Zombie_Conehead_hp_Inject_Code - ZOMBIE_CONEHEAD_HP_CODE_ADDRESS - sizeof(CHAR) * 5;
	memcpy(&sZombie_Conehead_hp_Modified_Code[1], &offset, sizeof(CHAR) * 4);
	
	offset2 = (ZOMBIE_CONEHEAD_HP_CODE_ADDRESS + sizeof(CHAR) * 6) - (sAlloc_Zombie_Conehead_hp_Inject_Code + sizeof(CHAR) * 15);
	memcpy(&sZombie_Conehead_hp_Inject_Code[11], &offset2, sizeof(CHAR) * 4);
	WriteProcessMemory(gGameProcess, (LPVOID)sAlloc_Zombie_Conehead_hp_Inject_Code, sZombie_Conehead_hp_Inject_Code, sizeof(CHAR) * 19, NULL);

	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_CONEHEAD_HP_CODE_ADDRESS, sizeof(CHAR) * 6, PAGE_EXECUTE_READWRITE, &oldProtect);
	WriteProcessMemory(gGameProcess, (LPVOID)ZOMBIE_CONEHEAD_HP_CODE_ADDRESS, sZombie_Conehead_hp_Modified_Code, sizeof(CHAR) * 6, NULL);
	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_CONEHEAD_HP_CODE_ADDRESS, sizeof(CHAR) * 6, oldProtect, &oldProtect);


	/* �޸���դ�ŵĻ����� */
	sAlloc_Zombie_Screendoor_hp_Inject_Code = (DWORD)VirtualAllocEx(gGameProcess, 0, sizeof(CHAR) * 15, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	offset = sAlloc_Zombie_Screendoor_hp_Inject_Code - ZOMBIE_SCREENDOOR_HP_CODE_ADDRESS - sizeof(CHAR) * 5;
	memcpy(&sZombie_Screendoor_hp_Modified_Code[1], &offset, sizeof(CHAR) * 4);

	offset2 = (ZOMBIE_SCREENDOOR_HP_CODE_ADDRESS + sizeof(CHAR) * 6) - (sAlloc_Zombie_Screendoor_hp_Inject_Code + sizeof(CHAR) * 15);
	memcpy(&sZombie_Screendoor_hp_Inject_Code[11], &offset2, sizeof(CHAR) * 4);
	WriteProcessMemory(gGameProcess, (LPVOID)sAlloc_Zombie_Screendoor_hp_Inject_Code, sZombie_Screendoor_hp_Inject_Code, sizeof(CHAR) * 15, NULL);

	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_SCREENDOOR_HP_CODE_ADDRESS, sizeof(CHAR) * 6, PAGE_EXECUTE_READWRITE, &oldProtect);
	WriteProcessMemory(gGameProcess, (LPVOID)ZOMBIE_SCREENDOOR_HP_CODE_ADDRESS, sZombie_Screendoor_hp_Modified_Code, sizeof(CHAR) * 6, NULL);
	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_SCREENDOOR_HP_CODE_ADDRESS, sizeof(CHAR) * 6, oldProtect, &oldProtect);

}

void EndQuicklyKill()
{
	DWORD oldProtect;
	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_HP_CODE_ADDRESS, sizeof(CHAR) * 6, PAGE_EXECUTE_READWRITE, &oldProtect);
	WriteProcessMemory(gGameProcess, (LPVOID)ZOMBIE_HP_CODE_ADDRESS, sZombie_hp_Origin_Code, sizeof(CHAR) * 6, NULL);
	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_HP_CODE_ADDRESS, sizeof(CHAR) * 6, oldProtect, &oldProtect);

	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_CONEHEAD_HP_CODE_ADDRESS, sizeof(CHAR) * 6, PAGE_EXECUTE_READWRITE, &oldProtect);
	WriteProcessMemory(gGameProcess, (LPVOID)ZOMBIE_CONEHEAD_HP_CODE_ADDRESS, sZombie_Conehead_hp_Origin_Code, sizeof(CHAR) * 6, NULL);
	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_CONEHEAD_HP_CODE_ADDRESS, sizeof(CHAR) * 6, oldProtect, &oldProtect);

	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_SCREENDOOR_HP_CODE_ADDRESS, sizeof(CHAR) * 6, PAGE_EXECUTE_READWRITE, &oldProtect);
	WriteProcessMemory(gGameProcess, (LPVOID)ZOMBIE_SCREENDOOR_HP_CODE_ADDRESS, sZombie_Screendoor_hp_Origin_Code, sizeof(CHAR) * 6, NULL);
	VirtualProtectEx(gGameProcess, (LPVOID)ZOMBIE_SCREENDOOR_HP_CODE_ADDRESS, sizeof(CHAR) * 6, oldProtect, &oldProtect);
	
	VirtualFreeEx(gGameProcess, (LPVOID)sAlloc_Zombie_hp_Inject_Code, 0, MEM_RELEASE);
	VirtualFreeEx(gGameProcess, (LPVOID)sAlloc_Zombie_Conehead_hp_Inject_Code, 0, MEM_RELEASE);
	VirtualFreeEx(gGameProcess, (LPVOID)sAlloc_Zombie_Screendoor_hp_Inject_Code, 0, MEM_RELEASE);
}

