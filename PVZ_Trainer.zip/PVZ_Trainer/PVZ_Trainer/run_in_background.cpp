#include <iostream>
#include <Windows.h>
#include "run_in_background.h"
using namespace std;

extern DWORD GetOffsetPointer(HANDLE hProcess, DWORD ptr, int offsetCount, ...);
extern HANDLE gGameProcess;

const DWORD GAME_PAUSE_BASE_ADDRESS = 0x7296FC;
const DWORD GAME_PAUSE_VALUE = 0;

static DWORD sGame_Pause_Addr;
static BOOL sRunInBackground = FALSE;

static DWORD WINAPI RunInBackground(LPVOID data)
{
	while (sRunInBackground)
	{
		Sleep(1);
		WriteProcessMemory(gGameProcess, (LPVOID)sGame_Pause_Addr, &GAME_PAUSE_VALUE, sizeof(DWORD), NULL);
	}
	return 0;
}

void StartRunInBackground()/* ��̨���� */
{
	sGame_Pause_Addr = GetOffsetPointer(gGameProcess, GAME_PAUSE_BASE_ADDRESS, 2, 0x868, 0x17C);
	sRunInBackground = TRUE;
	CreateThread(NULL, 0, RunInBackground, NULL, 0, 0);
}

void EndRunInBackground()
{
	sRunInBackground = FALSE;
}
