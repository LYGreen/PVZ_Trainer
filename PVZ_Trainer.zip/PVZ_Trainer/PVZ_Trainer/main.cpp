#include <iostream>
#include <stdarg.h>
#include <Windows.h>
#include "sun.h"
#include "money.h"
#include "cdtime.h"
#include "run_in_background.h"
#include "quickly_kill.h"
using namespace std;

extern DWORD GetOffsetPointer(HANDLE hProcess, DWORD ptr, int offsetCount, ...);

HANDLE gGameProcess;
static void Init();

int main(int argc, char* argv[])
{
	Init();
	StartInfiniteSun();
	StartInfiniteMoney();
	StartNoneCDTime();
	StartRunInBackground();
	StartQuicklyKill();

	cout << "Enable !" << endl;
	system("Pause");

	EndInfiniteSun();
	EndInfiniteMoney();
	EndNoneCDTime();
	EndRunInBackground();
	EndQuicklyKill();

	return 0;
}

void Init()
{
	HWND hWnd = FindWindowA(NULL, "Plants vs. Zombies");
	DWORD pId;
	GetWindowThreadProcessId(hWnd, &pId);
	gGameProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pId);
}


