#include <iostream>
#include <Windows.h>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Check_Button.H>
#include "sun.h"
#include "money.h"
#include "cdtime.h"
#include "run_in_background.h"
#include "quickly_kill.h"

class MainWindow :public Fl_Double_Window
{
    virtual int handle(int e)
    {
        switch (e)
        {
        case Fl_Event::FL_HIDE:
            EndInfiniteSun();
            EndInfiniteMoney();
            EndNoneCDTime();
            EndRunInBackground();
            EndQuicklyKill();
            break;
        }
        return Fl_Double_Window::handle(e);
    }
public:
    MainWindow(int W, int H, const char* l = (const char*)0) :Fl_Double_Window(W, H, l) {};
};
MainWindow* gMainWindow = (MainWindow*)0;
Fl_Check_Button* CheckBox_InfiniteSun = (Fl_Check_Button*)0;
Fl_Check_Button* CheckBox_InfiniteMoney = (Fl_Check_Button*)0;
Fl_Check_Button* CheckBox_NoneCDTime = (Fl_Check_Button*)0;
Fl_Check_Button* CheckBox_RunInBackground = (Fl_Check_Button*)0;
Fl_Check_Button* CheckBox_QuicklyKill = (Fl_Check_Button*)0;
Fl_Button* Button_EnableAll = (Fl_Button*)0;
Fl_Button* Button_DisableAll = (Fl_Button*)0;

HANDLE gGameProcess;

void OpenPVZ();
void InitWidgets();
void OnCheckBox_InfiniteSunChanged(Fl_Widget* w, void* data);
void OnCheckBox_InfiniteMoneyChanged(Fl_Widget* w, void* data);
void OnCheckBox_NoneCDTimeChanged(Fl_Widget* w, void* data);
void OnCheckBox_RunInBackgroundChanged(Fl_Widget* w, void* data);
void OnCheckBox_QuicklyKillChanged(Fl_Widget* w, void* data);
void OnButton_EnableAllReleased(Fl_Widget* w, void* data);
void OnButton_DisableAllReleased(Fl_Widget* w, void* data);
void OnWindow_gMainWindowClosed(Fl_Widget* w, void* data);

/* int main(int argc, char** argv) */
int WINAPI WinMain(_In_ HINSTANCE hInstance,_In_opt_ HINSTANCE hPrevInstance,_In_ LPSTR lpCmdLine,_In_ int nShowCmd)
{
    OpenPVZ();
    InitWidgets();
    return Fl::run();
}

void OpenPVZ()
{
    HWND hWnd = FindWindowA(NULL, "Plants vs. Zombies");
    if (hWnd == NULL)
    {
        MessageBoxA(NULL, "Can't find Plants vs. Zombies.", "Tip", MB_ICONERROR);
        exit(0);
    }
    DWORD pId;
    GetWindowThreadProcessId(hWnd, &pId);
    gGameProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pId);
}

void InitWidgets() 
{
    gMainWindow = new MainWindow(256, 104,"PVZ Trainer");
    gMainWindow->align(Fl_Align(FL_ALIGN_CLIP | FL_ALIGN_INSIDE));
    //gMainWindow->when(FL_WHEN_CHANGED);
    //gMainWindow->callback(OnWindow_gMainWindowClosed);

    CheckBox_InfiniteSun = new Fl_Check_Button(0, 0, 80, 25, "\346\227\240\351\231\220\351\230\263\345\205\211");
    CheckBox_InfiniteSun->down_box(FL_DOWN_BOX);
    CheckBox_InfiniteSun->when(FL_WHEN_CHANGED);
    CheckBox_InfiniteSun->callback(OnCheckBox_InfiniteSunChanged);

    CheckBox_InfiniteMoney = new Fl_Check_Button(145, 0, 80, 25, "\346\227\240\351\231\220\351\207\221\345\270\201");
    CheckBox_InfiniteMoney->down_box(FL_DOWN_BOX);
    CheckBox_InfiniteMoney->when(FL_WHEN_CHANGED);
    CheckBox_InfiniteMoney->callback(OnCheckBox_InfiniteMoneyChanged);

    CheckBox_NoneCDTime = new Fl_Check_Button(0, 25, 94, 25, "\346\227\240\345\206\267\345\215\264\346\227\266\351\227\264");
    CheckBox_NoneCDTime->down_box(FL_DOWN_BOX);
    CheckBox_NoneCDTime->when(FL_WHEN_CHANGED);
    CheckBox_NoneCDTime->callback(OnCheckBox_NoneCDTimeChanged);

    CheckBox_RunInBackground = new Fl_Check_Button(145, 25, 92, 25, "\345\217\257\345\220\216\345\217\260\350\277\220\350\241\214");
    CheckBox_RunInBackground->down_box(FL_DOWN_BOX);
    CheckBox_RunInBackground->when(FL_WHEN_CHANGED);
    CheckBox_RunInBackground->callback(OnCheckBox_RunInBackgroundChanged);

    CheckBox_QuicklyKill = new Fl_Check_Button(0, 50, 95, 25, "\347\247\222\346\235\200\345\203\265\345\260\270(?)");
    CheckBox_QuicklyKill->down_box(FL_DOWN_BOX);
    CheckBox_QuicklyKill->when(FL_WHEN_CHANGED);
    CheckBox_QuicklyKill->callback(OnCheckBox_QuicklyKillChanged);

    Button_EnableAll = new Fl_Button(5, 75, 100, 25, "\345\205\250\351\203\250\345\220\257\347\224\250");
    Button_EnableAll->when(FL_WHEN_RELEASE_ALWAYS);
    Button_EnableAll->callback(OnButton_EnableAllReleased);

    Button_DisableAll = new Fl_Button(150, 75, 100, 25, "\345\205\250\351\203\250\347\246\201\347\224\250");
    Button_DisableAll->when(FL_WHEN_RELEASE_ALWAYS);
    Button_DisableAll->callback(OnButton_DisableAllReleased);

    gMainWindow->color(FL_BACKGROUND2_COLOR);
    Button_EnableAll->color(FL_BACKGROUND2_COLOR);
    Button_EnableAll->color2(FL_BACKGROUND2_COLOR);
    Button_DisableAll->color(FL_BACKGROUND2_COLOR);
    Button_DisableAll->color2(FL_BACKGROUND2_COLOR);

    gMainWindow->end();
    gMainWindow->show();
}

void OnCheckBox_InfiniteSunChanged(Fl_Widget* w, void* data)
{
    Fl_Check_Button* but = (Fl_Check_Button*)w;
    if (but->value())
    {
        StartInfiniteSun();
    }
    else
    {
        EndInfiniteSun();
    }
}

void OnCheckBox_InfiniteMoneyChanged(Fl_Widget* w, void* data)
{
    Fl_Check_Button* but = (Fl_Check_Button*)w;
    if (but->value())
    {
        StartInfiniteMoney();
    }
    else
    {
        EndInfiniteMoney();
    }
}

void OnCheckBox_NoneCDTimeChanged(Fl_Widget* w, void* data)
{
    Fl_Check_Button* but = (Fl_Check_Button*)w;
    if (but->value())
    {
        StartNoneCDTime();
    }
    else
    {
        EndNoneCDTime();
    }
}

void OnCheckBox_RunInBackgroundChanged(Fl_Widget* w, void* data)
{
    Fl_Check_Button* but = (Fl_Check_Button*)w;
    if (but->value())
    {
        StartRunInBackground();
    }
    else
    {
        EndRunInBackground();
    }
}

void OnCheckBox_QuicklyKillChanged(Fl_Widget* w, void* data)
{
    Fl_Check_Button* but = (Fl_Check_Button*)w;
    if (but->value())
    {
        StartQuicklyKill();
    }
    else
    {
        EndQuicklyKill();
    }
}

void OnButton_EnableAllReleased(Fl_Widget* w, void* data)
{
    CheckBox_InfiniteSun->value(1);
    CheckBox_InfiniteMoney->value(1);
    CheckBox_NoneCDTime->value(1);
    CheckBox_RunInBackground->value(1);
    CheckBox_QuicklyKill->value(1);

    CheckBox_InfiniteSun->do_callback();
    CheckBox_InfiniteMoney->do_callback();
    CheckBox_NoneCDTime->do_callback();
    CheckBox_RunInBackground->do_callback();
    CheckBox_QuicklyKill->do_callback();
}

void OnButton_DisableAllReleased(Fl_Widget* w, void* data)
{
    CheckBox_InfiniteSun->value(0);
    CheckBox_InfiniteMoney->value(0);
    CheckBox_NoneCDTime->value(0);
    CheckBox_RunInBackground->value(0);
    CheckBox_QuicklyKill->value(0);

    CheckBox_InfiniteSun->do_callback();
    CheckBox_InfiniteMoney->do_callback();
    CheckBox_NoneCDTime->do_callback();
    CheckBox_RunInBackground->do_callback();
    CheckBox_QuicklyKill->do_callback();
}
